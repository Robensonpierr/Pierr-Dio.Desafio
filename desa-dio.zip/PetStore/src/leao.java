public class leao extends Mamifero {
	private static final long serialversionUID=1L;
	private String especie;
	
	public String soar() {
		return "faz roar";
}
public leao(String nome, int idade, String dono) {
	super(nome, idade,dono);
	this.especie = "Panthera";
}

}

package desafioDio;

public class Main {

	public static void main(String[] args) {
	Cliente Pierre = new Cliente();
	Pierre.setNome("Pierre");
	
	Conta cc = new contaCorrente(Pierre);
	cc.depositar(200);
	Conta poupan�a = new contaPoupan�a(Pierre);
	
	cc.transferir(200, poupan�a);
	
	
	cc.imprimirExtrato();
	poupan�a.imprimirExtrato();
	
		

	}

}

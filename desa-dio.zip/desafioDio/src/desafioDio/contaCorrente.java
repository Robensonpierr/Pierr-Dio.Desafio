package desafioDio;

public class contaCorrente extends Conta {
	
		public contaCorrente(Cliente cliente) {
		super(cliente);
		
	}

		@Override
		public void imprimirExtrato() {
		
			System.out.println("extrato conta corrente");
			super.imprimirInfoCom();
			
	}

}


package desafioDio;

public class contaPoupan�a  extends Conta {
	
	
	public contaPoupan�a(Cliente cliente) {
		super(cliente);
		 
	}

	@Override
	public void imprimirExtrato() {
		
		System.out.println("extrato conta poupan�a...");
		
		super.imprimirInfoCom();
	}
	

	

	
	
}
